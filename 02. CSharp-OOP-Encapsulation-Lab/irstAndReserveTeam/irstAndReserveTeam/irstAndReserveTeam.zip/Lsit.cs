﻿namespace PersonsInfo
{
    internal class Lsit<T>
    {
    }
}