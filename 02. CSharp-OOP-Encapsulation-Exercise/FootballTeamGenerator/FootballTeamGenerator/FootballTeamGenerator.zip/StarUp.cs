﻿using FootballTeamGenerator.Core;

namespace FootballTeamGenerator
{
    public class StarUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
