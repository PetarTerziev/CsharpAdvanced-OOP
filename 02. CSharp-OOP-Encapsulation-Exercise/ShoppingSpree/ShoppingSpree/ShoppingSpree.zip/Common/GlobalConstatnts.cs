﻿
namespace ShoppingSpree.Common
{
    class GlobalConstatnts
    {
        public const string EmptyNameExcMsg = "Name cannot be empty";
        public const string NegativeValueMsg = "Money cannot be negative";

    }
}
